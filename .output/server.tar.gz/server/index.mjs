import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
import './chunks/_/nitro.mjs';
export { n as default } from './chunks/routes/api/search.mjs';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
//# sourceMappingURL=index.mjs.map
